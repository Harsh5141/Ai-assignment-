# MusicWebsite

 a music streaming website designed mainly by PHP with MySql.
